STRONA DLA MICHASI — OD OSKARKA

W ZIP-ie jest index.html — cała strona.

JAK OPUBLIKOWAĆ ZA DARMO NA GITHUB PAGES:
1. Zaloguj się na https://github.com
2. Utwórz publiczne repozytorium o nazwie michasia-dla-ciebie.
3. Wgraj do niego plik index.html.
4. Otwórz Settings -> Pages.
5. W Build and deployment wybierz Deploy from a branch.
6. Wybierz branch main oraz folder /(root), potem Save.
7. Poczekaj, aż GitHub pokaże adres, zwykle https://TWOJ-LOGIN.github.io/michasia-dla-ciebie/

KOD QR:
Po opublikowaniu wklej prawdziwy adres strony na https://www.qrcode-monkey.com/ i wygeneruj kod QR.

WAŻNE:
Hasło KochamCie jest sprawdzane po stronie przeglądarki i jest tylko prostą blokadą-niespodzianką, nie prawdziwym zabezpieczeniem. Strona GitHub Pages jest publiczna dla osób znających link.
